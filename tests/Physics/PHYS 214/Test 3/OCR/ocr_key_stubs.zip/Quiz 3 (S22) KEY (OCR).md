# Quiz 3 (S22) KEY — OCR Extract

[OCR pending. Use the page images with an OCR tool to extract text.]
